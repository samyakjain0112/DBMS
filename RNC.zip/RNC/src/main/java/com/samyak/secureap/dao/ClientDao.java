package com.samyak.secureap.dao;

import com.samyak.secureap.models.Client;

public interface ClientDao {

	Client getAllDetailsClient(int loginId);
}
